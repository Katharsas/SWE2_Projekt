package swe2.shared.net;

public class ConnectionDefaults {
	public static final String IP = "localhost";
	public static final int PORT = 6666;
}
